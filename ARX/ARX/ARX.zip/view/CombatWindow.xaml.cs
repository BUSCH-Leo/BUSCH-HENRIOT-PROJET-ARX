﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System;
using System.Collections.Generic;
using ARX.model;


namespace ARX.view
{
    /// <summary>
    /// Logique d'interaction pour CombatWindow.xaml
    /// </summary>
    public partial class CombatWindow : Window
    {
        private Random random = new Random();
        private List<Item> inventory = new List<Item>();

        public CombatWindow()
        {
            InitializeComponent();
            LoadImages();
            InitializeCombat();
        }

        private void LoadImages()
        {
            BackgroundImage.Source = new BitmapImage(new Uri("view/Images/maze.png", UriKind.Relative));
            EnemyImage.Source = new BitmapImage(new Uri("view/Images/creature.png", UriKind.Relative));
        }

        private void InitializeCombat()
        {
            UpdateHealthDisplays();
            EnemyNameText.Text = $"Ennemi : {currentEnemy.Nom}";
        }

        private void UpdateHealthDisplays()
        {
            PlayerHealthText.Text = $"Player Health: {playerHealth}";
            PlayerHealthText.Foreground = Brushes.White;
            EnemyHealthText.Text = $"Enemy Health: {currentEnemy.Vie}";
            EnemyHealthText.Foreground = Brushes.White;
        }

        private void PlayerAttack(int minDamage, int maxDamage)
        {
            int damage = random.Next(minDamage, maxDamage + 1);
            currentEnemy.Vie -= damage;
            if (currentEnemy.Vie < 0) currentEnemy.Vie = 0;
            MessageBox.Show($"You dealt {damage} damage to the enemy!");
            UpdateHealthDisplays();

            if (currentEnemy.Vie > 0)
            {
                EnemyAttack();
            }
            else
            {
                MessageBox.Show("You defeated the enemy!");
                Close();
            }
        }

        private void EnemyAttack()
        {
            int damage = random.Next(currentEnemy.degaMin, currentEnemy.degaMax + 1);
            playerHealth -= damage;
            if (playerHealth < 0) playerHealth = 0;
            MessageBox.Show($"The enemy dealt {damage} damage to you!");
            UpdateHealthDisplays();

            if (playerHealth <= 0)
            {
                MessageBox.Show("You have been defeated!");
                Close();
            }
        }

        private void AttackButton_Click(object sender, RoutedEventArgs e)
        {
            PlayerAttack(10, 15);
        }

        private void FleeButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("You fled from the battle!");
            Close();
        }

        private void InventoryButton_Click(object sender, RoutedEventArgs e)
        {
            InventoryWindow inventoryWindow = new InventoryWindowCombat(playerHealth, inventory);
            inventoryWindow.Owner = this;
            inventoryWindow.ShowDialog();
            playerHealth = inventoryWindow.PlayerHealth;
            UpdateHealthDisplays();
        }
    }
}
