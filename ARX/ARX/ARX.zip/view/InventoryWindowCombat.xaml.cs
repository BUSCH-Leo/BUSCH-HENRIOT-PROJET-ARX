﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using ARX.model;
using ARX.view;

namespace ARX.view
{
    public partial class InventoryWindow : Window
    {
        public int PlayerHealth { get; private set; }
        private List<Item> inventory;

        public InventoryWindow(int currentHealth, List<Item> inventory)
        {
            InitializeComponent();
            PlayerHealth = currentHealth;
            this.inventory = inventory;
            InitializeInventoryCombat();
        }

        private void InitializeInventoryCombat()
        {
            foreach (var item in inventory)
            {
                ListBoxItem listBoxItem = new ListBoxItem
                {
                    Content = item.Name,
                    Tag = item
                };
                listBoxItem.Selected += ListBoxItem_Selected;
                InventoryListBox.Items.Add(listBoxItem);
            }
        }

        private void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {
            var selectedItem = (ListBoxItem)sender;
            var item = (Loot)selectedItem.Tag;

            if (item.Type == "Potion")
            {
                PlayerHealth += item.EffectValue;
                if (PlayerHealth > 100) PlayerHealth = 100; // Assuming max health is 100
                MessageBox.Show($"You used a {item.Name}!");
            }

            // Remove item from inventory after use (optional)
            inventory.Remove(item);
            InventoryListBox.Items.Remove(selectedItem);

            Close();
        }
    }
}
